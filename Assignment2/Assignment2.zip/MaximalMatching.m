function [vc,runtime,v] = runf(n,e,u)
tic;
v = [];
while length(e) > 0
    k = randi([1 length(e)]);
    v = [v;e(k);u(k)];
    [e,u] = deleteedges(e,u,k);
end
vc = length(v);
runtime = toc;
    
    %delete edges at location k
    function [ne,nu] = deleteedges(e,u,k)
        i = e(k);
        j = u(k);
        location1 = find(e == i);
        location2 = find(u == i);
        location3 = find(e == j);
        location4 = find(u == j);
        location = [location1;location2;location3;location4];
        e(location) = [];
        u(location) = [];
        ne = e;
        nu = u;
    end
end