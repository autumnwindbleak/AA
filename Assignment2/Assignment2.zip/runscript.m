folder = 'input\';
files = getfiles(folder);
header = cell(1,7);
header(1) ={'Filename'};
header(2) ={'Greedy Min VC'};
header(3) = {'Greedy Time(s)'};
header(4) ={'2-Approximation Min VC'};
header(5) = {'2-Approximation Time(s)'};
header(6) = {'improvedGreedy Min VC'};
header(7) = {'improvedGreedy Time(s)'};
xlswrite('result.xls',header,1,'A1');
vcg = [];
vca = [];
vci = [];
runtimeg = [];
runtimea = [];
runtimei = [];
if length(files) ~=0
    for i = 1:length(files);
        filename = [files(i).folder,'\',files(i).name];
        %disp(files(i).name);
        [n,e,u] = readf(filename);
        [gvc,gruntime,gv] = Greedy(n,e,u);
        [avc,aruntime,av] = MaximalMatching(n,e,u);
        [ivc,iruntime,iv] = improvedGreedy(n,e,u);
        filename = files(i).name;
        disp([filename ' Greedy: VC: ' num2str(gvc) ' TIME: ' num2str(gruntime) 's ''Approximation: VC: ' num2str(avc) ' TIME: ' num2str(aruntime) 's''improvedGreedy: VC: ' num2str(ivc) ' TIME: ' num2str(iruntime) 's']);
        tab = cell(1,7);
        tab(1) = {files(i).name};
        tab(2) = {gvc};
        tab(3) = {gruntime};
        tab(4) = {avc};
        tab(5) = {aruntime};
        tab(6) = {ivc};
        tab(7) = {iruntime};
        xlswrite('result.xls',tab,1,['A' num2str(i+1)]);
        vcg = [vcg;gvc];
        vca = [vca;avc];
        vci = [vci;ivc];
        runtimeg = [runtimeg;gruntime];
        runtimea = [runtimea;aruntime];
        runtimei = [runtimei;iruntime];
    end
else
    disp('Wrong path');
end
figure(1);
plot(vcg,'.-');
hold on;
plot(vca,'.-');
plot(vci,'.-');
hold off;
legend('Greedy','2-Approximation','improvedGreedy');
figure(2);
plot(runtimeg,'.-');
hold on;
plot(runtimea,'.-');
plot(runtimei,'.-');
hold off;
legend('Greedy','2-Approximation','improvedGreedy');

%get all input files in the folder
function allfiles = getfiles(f)
folders = dir(f);
n = length(folders);
allfiles = [];
if  n >= 3
    for i = 3:n
        fn = [f,folders(i).name];
        %disp(fn);
        files = dir([fn '\']);
        nf = length(files);
        if nf >= 3
            for j = 3: nf
                allfiles = [allfiles; files(j)];
            end
        else
            disp(['Subfolder' fn 'is empty, will be ignored.']);
        end
    end
else
    disp('Folder empty or not exist');
end
end


%read from file and put edges into e,u. n is the number of nodes
function [n,e,u] = readf(f)
[s,e,u] = textread(f,'%s%d%d','headerlines',1);
[s1,s2,n,edge] = textread(f,'%s%s%d%d',[1]);
locatione = find(e == 0);
locationu = find(u == 0);
e(locatione) = [];
u(locatione) = [];
e(locationu) = [];
u(locationu) = [];
end