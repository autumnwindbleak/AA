function [vc,runtime,v] = runf(n,e,u)
tic;
v = [];
while(length(e)>0)
    [location, node] = findmax(e,u,n);
    k = findedge(location,e,u);
    v = [v;e(k);u(k)];
    [e,u] = deleteedges(e,u,k);
end
vc = length(v);
runtime = toc;

    function k = findedge(location,e,u)
        k1 = randi([1 length(location)]);
        k = location(k1);
    end

    %delete edges at location k
    function [ne,nu] = deleteedges(e,u,k)
        i = e(k);
        j = u(k);
        location1 = find(e == i);
        location2 = find(u == i);
        location3 = find(e == j);
        location4 = find(u == j);
        location = [location1;location2;location3;location4];
        e(location) = [];
        u(location) = [];
        ne = e;
        nu = u;
    end



    %find the node with max degree and return the location of the edges
    function [location,node] = findmax(e,u,n)
        %count up degree
        degree = zeros(n);
        for i=1:size(e)
            degree(e(i)) = degree(e(i)) + 1;
            degree(u(i)) = degree(u(i)) + 1;
        end
        %found max degree node
        nodes = find(degree == max(degree));
        node = nodes(1);
        %found all locations of edges that cover this node
        locatione = find(e == node);
        locationu = find(u == node);
        location = [locationu;locatione];
        
    end
end