function [vc,runtime,v] = runf(n,e,u)
tic;
v = [];

while(length(e)>0)
    [location, node] = findmax(e,u,n);
    v = [v;node];
    [e,u] = deleteedges(location,e,u);
end
vc = length(v);
runtime = toc;


    %delete the edges at location
    function [ne,nu] = deleteedges(location,e,u)
        e(location) = [];
        ne = e;
        u(location) = [];
        nu = u;
    end


    %find the node with max degree and return the location of the edges
    function [location,node] = findmax(e,u,n)
        %count up degree
        degree = zeros(n,1);
        for i=1:size(e)
            degree(e(i)) = degree(e(i)) + 1;
            degree(u(i)) = degree(u(i)) + 1;
        end
        %found max degree node
        nodes = find(degree == max(degree));
        node = nodes(1);
        degree(node) = 0;
        %found all locations of edges that cover this node
        locatione = find(e == node);
        locationu = find(u == node);
        location = [locationu;locatione];
    end
end